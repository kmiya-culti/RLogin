
#define CLEFIA_BLOCK_SIZE 16

#define CLEFIA_KEY_SIZE 32

/* Allow keys of size 128 <= bits <= 256 */

#define CLEFIA_MIN_KEY_SIZE 16
#define CLEFIA_MAX_KEY_SIZE 32

struct clefia_ctx
{
  int r;
  unsigned char rk[8 * 26 + CLEFIA_MAX_KEY_SIZE]; /* 8 bytes x 26 rounds(max) + whitening keys */
};

void ClefiaKeySet(struct clefia_ctx *ctx, const unsigned char *skey, const int key_bitlen);
void ClefiaEncrypt(struct clefia_ctx *ctx, unsigned char *ct, const unsigned char *pt);
void ClefiaDecrypt(struct clefia_ctx *ctx, unsigned char *pt, const unsigned char *ct);

