#include    <stdio.h>
#include    <stdlib.h>
#include    <string.h>
#include    <sys/types.h>
#include    <termios.h>
#include    <fcntl.h>
#include    <signal.h>
#include    <sys/ioctl.h>
#include    <sys/stat.h>
#include    <time.h>
#include    <paths.h>

#define	FALSE	0
#define	TRUE	1
#define	ERR	(-1)

static	int	dir_chk = FALSE;
static	int	base_chk = FALSE;
static	char	*alternate_file = NULL;

#ifdef	DEBUG

static	FILE	*debug_fp;

void	DEBUG_OPEN()
{
    debug_fp = fopen("log","w");
}
void	DEBUG_CLOSE()
{
    fclose(debug_fp);
}
void	debug(fm,p1,p2,p3,p4)
char	*fm,*p1,*p2,*p3,*p4;
{
    fprintf(debug_fp,fm,p1,p2,p3,p4);
}
#endif

static  int     aux_in  = 0;
static  int     aux_out = 1;
static	int	get_len = 0;
static	int	get_pos = 0;
static	char	get_buf[4096];

int	GET_AUX()
{
    fd_set  fds;
    struct timeval   timeout;

RETRY:
    if ( get_len > get_pos ) {
#ifdef	DEBUG
	debug("R[%02x]\n", get_buf[get_pos]);
#endif
	return (get_buf[get_pos++] & 0xff);
    }

    FD_ZERO(&fds);
    FD_SET(aux_in, &fds);
    timeout.tv_sec = 3;
    timeout.tv_usec = 0;

    if ( select(aux_in + 1, &fds, 0, 0, &timeout) > 0 &&
	  FD_ISSET(aux_in, &fds) &&
          (get_len = read(aux_in, get_buf, 4096)) > 0 ) {
	get_pos = 0;
	goto RETRY;
    }

    return ERR;
}

void	WRITE(int fp, char *buf, int len)
{
    int     n;
    fd_set  ids, ods;

#ifdef	DEBUG
    debug("S");
    for ( n = 0 ; n < len ; n++ )
	debug("[%02x]", buf[n]);
    debug("\n");
#endif
    while ( len > 0 ) {
	if ( (n = write(fp, buf, len)) > 0 ) {
	    if ( (len -= n) <= 0 )
		break;
	    buf += n;
	}

    	FD_ZERO(&ods);
    	FD_SET(fp, &ods);

    	FD_ZERO(&ids);
	if ( get_len < 4096 )
    	    FD_SET(aux_in, &ids);

    	if ( select(fp + 1, &ids, &ods, 0, NULL) > 0 &&
		FD_ISSET(aux_in, &ids) &&
		(n = read(aux_in, get_buf + get_len, 4096 - get_len)) > 0 )
	    get_len += n;
    }
}
void    PUT_AUX(ch)
char    ch;
{
    WRITE(aux_out, &ch, 1);
}

static	int	aux_len = 0;
static	char	aux_buf[4096];

void    BUF_FLUSH(ch)
char    ch;
{
    WRITE(aux_out, aux_buf, aux_len);
    aux_len = 0;
}
void	BUF_SEND(ch)
char	ch;
{
    if ( aux_len >= 4096 )
	BUF_FLUSH();
    aux_buf[aux_len++] = ch;
}
/******************************************

    Unix BSD I/O Control

*******************************************/

static  struct termios old;

int	set_dev_opt()
{
    struct termios op;

    if ( ioctl(aux_in, TIOCGETA, &op) )
	return ERR;

    op.c_iflag = BRKINT | IGNPAR | IXON | IXOFF;
    op.c_oflag = OPOST;
    op.c_lflag = 0;
    op.c_cc[VMIN] = 1;
    op.c_cc[VTIME] = 1;

    if ( ioctl(aux_in, TIOCSETA, &op) )
	return ERR;

    return FALSE;
}
void    res_dev_opt()
{
    ioctl(aux_in, TIOCSETA, &old);
}
int     device_init()
{
    if ( ioctl(aux_in, TIOCGETA, &old) )
	return ERR;
    return set_dev_opt();
}
void    device_end()
{
    res_dev_opt();
}

void	chkdir(char *file)
{
    char    *p, *s;
 
    for ( p = file ; *p != '\0' ; p = s + 1 ) {
        for ( s = p ; *s != '/' ; s++ ) {
            if ( *s == '\0' )
                return;
        }
        *s = '\0';
	mkdir(file, S_IREAD | S_IWRITE | S_IEXEC |
		    S_IRGRP | S_IWGRP  | S_IXGRP |
		    S_IROTH | S_IWOTH  | S_IXOTH);
        *s = '/';
    }
}
char	*basename(char *file)
{
    char    *p;

    if ( alternate_file != NULL ) {
	file = alternate_file;
	alternate_file = NULL;
	return file;
    }

    if ( base_chk == FALSE )
	return file;

    if ( (p = strrchr(file, '/')) != NULL )
	file = p + 1;

    return file;
}
int	download(file, type)
char	*file;
int	type;
{
    if ( dir_chk )
	chkdir(file);
    return BP_recive(file, type);
}
int	upload(file, type)
char	*file;
int	type;
{
    int     st;
    FILE    *fp;

    if ( (fp = fopen(file,"r")) == NULL )
	return ERR;
    st = BP_send(basename(file), fp, type);
    fclose(fp);
    return st;
}
void	usage(char *prog)
{
    fprintf(stderr,
"Usage:%s [-u/d] [-mb] [-z <list>] <File> [-a <name>]\n"\
"	-u	host   -> remote Upload\n"\
"	-d	remote -> host   Download\n"\
"	-m	with Mkdir (-d onry)\n"\
"	-b	remote file Base strip\n"\
"	-t	Text Mode\n"\
"	-z ..	File name list\n"\
"	-a ..	Alernate remote file name\n",
	prog);
}
void	sighand()
{
    device_end();
    exit(0);
}

extern	int	optind;
extern	char	*optarg;

int	main(ac,av)
int	ac;
char	*av[];
{
    int    n;
    int    opt;
    int    mx = 1;
    int    md = 0;
    int    type = 'B';
    char   *p;
    char   *file = NULL;
    FILE   *fp;
    char   tmp[BUFSIZ];

#ifdef	DEBUG
    DEBUG_OPEN();
#endif

    for ( ; ; ) {
	while ( (opt = getopt(ac, av, "udmbz:a:t")) != EOF ) {
	    switch(opt) {
	    case 'd': md = 0; break;
	    case 'u': md = 1; break;
	    case 'm': dir_chk = TRUE; break;
	    case 'b': base_chk = TRUE; break;
	    case 'z': file = optarg; break;
	    case 'a': alternate_file = optarg; break;
	    case 't': type = 'A'; break;
	    default: usage(av[0]); exit(1);
	    }
	}
	if ( optind >= ac )
	    break;
	av[mx++] = av[optind++];
    }

    if ( device_init() ) {
	fprintf(stderr, "%s: device init error\n", av[0]);
	exit(1);
    }

    for ( n = 1 ; n < NSIG ; n++ )
	signal(n, sighand);

    if ( md == 0 && mx <= 1 )
	download("", type);

    while ( --mx > 0 ) {
	p = *(++av);
	if ( md == 0 ) {
	    if ( download(p, type) )
		goto ENDOF;
	} else {
	    if ( upload(p, type) )
		goto ENDOF;
	}
    }

    if ( file != NULL &&
	 (fp = fopen(file, "r")) != NULL ) {
	while ( fgets(tmp, BUFSIZ, fp) != NULL ) {
	    if ( (p = strchr(tmp, '\n')) != NULL )
		*p = '\0';
	    if ( tmp[0] == '\0' || tmp[0] == '#' )
		continue;

	    if ( md == 0 ) {
	        if ( download(tmp, type) )
		    goto ENDOF;
	    } else {
	        if ( upload(tmp, type) )
		    goto ENDOF;
	    }
	}
	fclose(fp);
    }

ENDOF:
    device_end();

#ifdef	DEBUG
    DEBUG_CLOSE();
#endif

    return 0;
}
